package com.esprit.note;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class NoteMSApplicationTests {

	@Test
	void contextLoads() {
	}
}
